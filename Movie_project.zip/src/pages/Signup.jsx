import { useState } from "react";
import { Link } from "react-router-dom";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Signup() {

    const [name, setName] = useState("");
    const [email, setEmail] = useState("");
    const [password, setPassword] = useState("");
    const [confirmPassword, setConfirmPassword] = useState("");
    const [errors, setErrors] = useState({});

    const navigate = useNavigate();

    const handleSubmit = (e) => {
        e.preventDefault();

        let newErrors = {};
        if (!name.trim()) {
            newErrors.name = "Name is required";
        }

        const emailPattern = /\S+@\S+\.\S+/;
        if (!email.trim()) {
            newErrors.email = "Email is required";
        } else if (!emailPattern.test(email)) {
            newErrors.email = "Invalid email format";
        }

        if (!password) {
            newErrors.password = "Password is required";
        } else if (password.length < 6) {
            newErrors.password = "Password must be at least 6 characters";
        }

        if (!confirmPassword) {
            newErrors.confirmPassword = "Confirm password required";
        } else if (password !== confirmPassword) {
            newErrors.confirmPassword = "Passwords do not match";
        }

        setErrors(newErrors);
        if (Object.keys(newErrors).length > 0) return;
        const user = { name, email, password };
        localStorage.setItem("user", JSON.stringify(user));
        toast.success(`${name} Signup successful`);
        navigate("/login");
        setName("");
        setEmail("");
        setPassword("");
        setConfirmPassword("");
    };

    return (
        <div className="flex justify-center items-center min-h-screen bg-gray-900 mt-3 rounded-2xl">
            <form onSubmit={handleSubmit} className="bg-gray-800 p-8 rounded-lg w-96 shadow-lg">
                <h2 className="text-white text-2xl mb-6 text-center font-semibold">
                    Create Account
                </h2>
                <label className="text-gray-300 text-sm">Name</label>
                <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
          ${errors.name ? "border-red-500" : "border-gray-600"}`} />
                {errors.name && (
                    <p className="text-red-500 text-xs mb-2">
                        {errors.name}
                    </p>
                )}

                <label className="text-gray-300 text-sm">Email</label>
                <input
                    type="text"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
          ${errors.email ? "border-red-500" : "border-gray-600"}`} />
                {errors.email && (
                    <p className="text-red-500 text-xs mb-2">
                        {errors.email}
                    </p>
                )}

                <label className="text-gray-300 text-sm">Password</label>
                <input
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
          ${errors.password ? "border-red-500" : "border-gray-600"}`} />
                {errors.password && (
                    <p className="text-red-500 text-xs mb-2">
                        {errors.password}
                    </p>
                )}

                <label className="text-gray-300 text-sm">Confirm Password</label>
                <input
                    type="password"
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
          ${errors.confirmPassword ? "border-red-500" : "border-gray-600"}`} />
                {errors.confirmPassword && (
                    <p className="text-red-500 text-xs mb-3">
                        {errors.confirmPassword}
                    </p>
                )}

                <p className="text-gray-400 text-sm mb-4">
                    Already have an account?{" "}
                    <Link
                        to="/login"
                        className="text-red-500 hover:underline"
                    >
                        Login
                    </Link>
                </p>

                <button
                    type="submit"
                    className="w-full bg-red-600 hover:bg-red-700 transition text-white py-2 rounded font-medium"
                >
                    Signup
                </button>

            </form>

        </div>
    );
}

export default Signup;