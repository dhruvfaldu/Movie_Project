import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { toast } from "react-toastify";

function Login() {

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const [errors, setErrors] = useState({});

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();

    let newErrors = {};

    if (!email.trim()) {
      newErrors.email = "Email is required";
    }

    if (!password.trim()) {
      newErrors.password = "Password is required";
    }

    setErrors(newErrors);

    if (Object.keys(newErrors).length > 0) return;

    const storedUser = JSON.parse(localStorage.getItem("user"));

    if (!storedUser) {
      setErrors({ email: "No user found. Please signup first" });
      return;
    }

    if (storedUser.email === email && storedUser.password === password) {
      localStorage.setItem("isLoggedIn", true);
      localStorage.setItem("currentUser", JSON.stringify(storedUser));
      toast.success(`${storedUser.name} Login successful`);
      navigate("/");
    } else {
      setErrors({ password: "Invalid email or password" });
    }
  };

  return (
    <div className="flex justify-center items-center min-h-screen bg-gray-900 mt-3 rounded-2xl">
      <div className="flex flex-col items-center">
        <h2 className="text-white text-2xl mb-6 font-semibold">
          MovieApp
        </h2>

        <form
          onSubmit={handleSubmit}
          className="bg-gray-800 p-8 rounded-lg w-96 shadow-lg"
        >

          <h2 className="text-white text-xl mb-6 text-center">
            Login
          </h2>

          <label className="text-gray-300 text-sm">
            Email
          </label>

          <input
            type="text"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
            ${errors.email ? "border-red-500" : "border-gray-600"}`}
          />

          {errors.email && (
            <p className="text-red-500 text-xs mb-3">
              {errors.email}
            </p>
          )}

          <label className="text-gray-300 text-sm">
            Password
          </label>

          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            className={`w-full p-2 rounded border mt-1 mb-1 bg-gray-700 text-white focus:outline-none
            ${errors.password ? "border-red-500" : "border-gray-600"}`}
          />
          {errors.password && (
            <p className="text-red-500 text-xs mb-3">
              {errors.password}
            </p>
          )}

          <p className="text-gray-400 text-sm mb-4">
            Don't have an account?{" "}
            <Link
              to="/signup"
              className="text-red-500 hover:underline"
            >
              Signup
            </Link>
          </p>

          <button
            type="submit"
            className="w-full bg-red-600 hover:bg-red-700 transition text-white py-2 rounded font-medium"
          >
            Login
          </button>

        </form>

      </div>

    </div>
  );
}

export default Login;